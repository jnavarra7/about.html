var itemname = [    "VINTAGE TOP", "VARSITY JACKET", "FUCLA SHIRT", "ROSE BOWL", "SWIM SHIRT", "SNOOPY", 
                    "BASEBALL SWEATS", "ORTHO SHORTS", "SC LEGGINGS", "YELLOW SHORTS", "WHITE SWEATS", "RED SWEATS"
];
var itemprice = [   "45", "65", "40", "35", "65", "65",
                    "45", "15", "13", "35", "75", "35"

];
var itemseller = [  "tommy trojan", "TT", "UCLA", "trojan tom", "A SWIMMER", "YUH", 
                    "really strong baseball man", "doctor", "ZEN", "yoga mom", "ME", "YUH"

];
var sellercontact = [   "tommy@usc.edu", "(123) 123-1234", "(123) 123-1234", "tommy@usc.edu", "(123) 123-1234", "123) 123-1234", 
                        "strong@usc.edu", "(123) 123-1234", "(123) 123-1234", "mommy@usc.edu", "(123) 123-1234", "(123) 123-1234"

];
var itemimage = [   "shirt.png", "varsity.png", "fuclashirt.png", "rosebowl.png", "swimshirt.png", "sweater.png",
                    "baseball.png", "ortho.png", "leggings.png", "shortssc.png", "white.png", "red.png"

];

var itemID = [  0, 1, 2, 3, 4, 5,
                6, 7, 8, 9, 10, 11 ]

/*

function addPrompt(itemID){
    document.write('<div class="center hideform">')
    document.write('Add ' + itemID + 'to favorites?')
    document.write('<br/> <br/>')
    document.write('<button id="add">Yes</button>')
    document.write('<button id="close">No</button>')
    document.write('</div> <br/>')
    document.write('$(".center").show();')
}
                
*/

function saveToFavorites(itemID){
    if(localStorage.getItem(itemID)){
        alert("This item is already in your favorites!");
        return 0;
    }
    else{
        localStorage.setItem(itemID, itemID);
    }
    
}

function removeFromFavorites(itemID){
    localStorage.removeItem(itemID);
}